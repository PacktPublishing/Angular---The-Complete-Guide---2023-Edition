import { createReducer } from '@ngrx/store';

const initialState = 0;

export const counterReducer = createReducer(
  initialState
);
