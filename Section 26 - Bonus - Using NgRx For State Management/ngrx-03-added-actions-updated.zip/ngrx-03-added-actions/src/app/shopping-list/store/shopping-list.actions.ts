import { Action } from '@ngrx/store';

import { Ingredient } from '../../shared/ingredient.model';

export const ADD_INGREDIENT = 'ADD_INGREDIENT';
export const ADD_INGREDIENTS = 'ADD_INGREDIENTS';

export class AddIngredient implements Action {
  readonly type = ADD_INGREDIENT;

  constructor(public payload: Ingredient) {}
}

export class AddIngredients implements Action {
  readonly type = ADD_INGREDIENTS;

  constructor(public payload: Ingredient[]) {}
}

export type ShoppingListActions = AddIngredient | AddIngredients;

// Alternative syntax (using createAction() and props()):
// import { createAction, props } from '@ngrx/store';

// export const AddIngredient = createAction(
//   '[Shopping List] Add Ingredient',
//   props<{ ingredient: Ingredient }>()
// );

// export const AddIngredients = createAction(
//   '[Shopping List] Add Ingredients',
//   props<{ ingredients: Ingredient[] }>()
// );
