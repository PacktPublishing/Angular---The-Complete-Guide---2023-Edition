import { Component } from '@angular/core';

@Component({
  templateUrl: './today.component.html',
})
export class TodayComponent {}
