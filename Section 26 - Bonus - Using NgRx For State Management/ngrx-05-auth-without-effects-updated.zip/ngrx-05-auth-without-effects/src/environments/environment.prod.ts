export const environment = {
  production: true,
  firebaseAPIKey: 'AIzaSyAz6xu_sSCmtb568XkRHsDFcpWmKWlhd9w'
};
